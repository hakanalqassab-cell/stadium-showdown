STADIUM SHOWDOWN — ONLINE MULTIPLAYER TEST BUILD

Files:
- index.html

IMPORTANT:
Online multiplayer needs internet access and the page must be served from a website (HTTPS), not opened as file://.
The online connection uses PeerJS's public signaling service and a browser-to-browser peer connection. This is a prototype; public signaling availability and school/network restrictions may affect connections.

HOW TO PLAY ONLINE:
1. Upload index.html to a static website host that gives you an HTTPS link (for example, GitHub Pages).
2. Open the hosted link on both computers.
3. Player 1 clicks CREATE ROOM and shares the room code.
4. Player 2 enters that code and clicks JOIN ROOM.
5. Both players click START MATCH.

CONTROLS:
- WASD or arrow keys: move
- Space / SHOOT: kick when close to the ball
- R: restart

NOTE:
This is an early multiplayer prototype. The host is authoritative for the shared ball/score, and the online simulation may need further tuning for latency and match flow.
